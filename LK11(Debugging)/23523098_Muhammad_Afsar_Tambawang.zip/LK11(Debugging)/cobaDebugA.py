NamaPengguna = "Muhammad Afsar Tambawang"
Label = "Selamat Datang, " + NamaPengguna
print(Label)