angka = [1, 4, 5, 10, 31, 7, 9, 23, 14]
sum = 0
for i in angka:
   sum = sum + i
print("Jumlah semua angka adalah: ")
print(sum)
