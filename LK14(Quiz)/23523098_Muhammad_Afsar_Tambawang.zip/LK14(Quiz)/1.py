x1, y1 , x2, y2 = input("Masukkan Koordinat :").split(" ")
x1 = int(x1)
x2 = int(x2)
y1 = int(y1)
y2 = int(y2)
calculate = abs(x1 - x2) + abs(y1 - y2)

print(calculate)
